<?php
/**
 * Arina Digital
 *
 **/

defined('ABSPATH') || exit; // Exit if accessed directly

// dynamic_sidebar('sidebar-footer')
// dynamic_sidebar('sidebar-footer-2')

?>
<footer class="footer">
    footer

    <div data-ajaxurl="<?php echo admin_url('admin-ajax.php'); ?>"></div>
</footer>
<?php wp_footer(); ?>

</body>
</html>

